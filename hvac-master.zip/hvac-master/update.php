<?php

$id = $_GET['id']; // get id through query string

$db =mysqli_connect("localhost","root","","autopozicovna");

$sql = "select * from auto where id='$id'";

$result = mysqli_query($db,$sql);

$data = mysqli_fetch_array($result);

if(isset($_POST['update'])) // when click on Update button
{
    $meno = $_POST['meno'];
    $cena = $_POST['cena'];
    $km = $_POST['km'];
    $typ = $_POST['typ'];
    $rok = $_POST['rok'];


    $edit = mysqli_query($db,"update auto set meno='$meno',cena='$cena', km='$km',typ='$typ',img_path='$img_path',rok='$rok' where id='$id'");

    if($edit)
    {
        mysqli_close($db); // Close connection
        header("location:admin.php"); // redirects to all records page
        exit;
    }
    else
    {
        echo mysqli_error($db);
    }
}

include ("header.php");
?>





<h3 class="text-center">Update Data</h3>




<div class="d-flex justify-content-center mb-3">
<form  method="POST">
    <div class="form-group">
        <label for="meno">Nazov:</label>
        <input type="text" name="meno"  class="form-control" value="<?php echo $data['meno'] ?>" >
    </div>
    <div class="form-group">
        <label for="cena">cena:</label>
        <input type="text" name="cena" class="form-control" value="<?php echo $data['cena'] ?>" >
    </div>
    <div class="form-group">
        <label for="km">km:</label>
        <input type="text" name="km" class="form-control" value="<?php echo $data['km'] ?>" >
    </div>
    <div class="form-group">
        <label for="typ">typ:</label>
        <input type="text" name="typ" class="form-control" value="<?php echo $data['typ'] ?>" >
    </div>
    <div class="form-group">
        <label for="rok">rok:</label>
        <input type="text" name="rok" class="form-control" value="<?php echo $data['rok'] ?>" >
    </div>
    <button type="submit" name="update" value="Update" class="btn btn-danger">Submit</button>
</form>
</div>

<?php include ("footer.php"); ?>