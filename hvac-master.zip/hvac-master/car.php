

<head>
<?php include_once ("header.php"); ?>
</head>






    <!-- Car Section Begin -->

        <div class="container" name="zoznam">
            <div class="row">
                    <div class="row" id ="auta">
                        <?php

                        $db =mysqli_connect("localhost","root","","autopozicovna");
                        $records = mysqli_query($db,"SELECT * FROM auto");

                        if (mysqli_num_rows($records) > 0) {
                            while($row = mysqli_fetch_assoc($records)) {
                                ?>
                                <div class="col-lg-4 col-md-4">
                                    <div class="car__item">
                                            <img src="<?php echo $row['img_path']; ?>" alt="Fotka auta sa nenašla" >

                                        <div class="car__item__text">
                                            <div class="car__item__text__inner">
                                                <div class="label-date"><?php echo $row['rok']; ?></div>
                                                <h5><a href="#"><?php echo ($row['meno']); ?></a></h5>
                                                <ul>
                                                    <li><span><?php echo $row['km']; ?></span> km</li>
                                                    <li><span><?php echo $row['typ']; ?></span> </li>
                                                </ul>
                                            </div>
                                            <div class="car__item__price">
                                                <a href="book_request.php" class="car-option">Najmi</a>
                                                <h6><?php echo $row['cena']; ?> €<span>/Deň</span></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php

                            }
                        } else {
                            echo "0 results";
                        }
                        ?>

                    </div>
            </div>
        </div>






