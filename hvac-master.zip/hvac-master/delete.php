<?php

$id = $_GET['id'];

$db = mysqli_connect("localhost","root","","autopozicovna");
$del = mysqli_query($db,"delete from auto where id = '$id'"); // delete query

if($del)
{
    mysqli_close($db);
    header("location:admin.php?uspesne_zmazane");
    exit;
}
else
{
    echo "Error deleting record";
}
?>