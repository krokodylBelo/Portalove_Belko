<?php


if(isset($_POST['submit']))
{
    $meno = $_POST['meno'];
    $cena = $_POST['cena'];
    $km = $_POST['km'];
    $typ = $_POST['typ'];

    $rok = $_POST['rok'];

    $db = mysqli_connect("localhost","root","","autopozicovna");

    $target_dir = "img/cars/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));



    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        } else {
            echo "File is not an image.";
        }
    }


    $img_path = $target_file;

    $insert = mysqli_query($db,"INSERT INTO `auto` (`id`, `meno`, `cena`, `km`, `typ`, `img_path`, `rok`) VALUES (NULL, '$meno', '$cena', '$km', '$typ', '$img_path', '$rok');");

    if(!$insert)
    {
        echo mysqli_error($db);
    }
    else
    {
        header("location:admin.php"); // redirects to all records page
        exit;
    }
    mysqli_close($db);
}
?>