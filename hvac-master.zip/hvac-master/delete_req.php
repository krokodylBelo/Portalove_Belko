<?php

$id = $_GET['id'];

$db = mysqli_connect("localhost","root","","autopozicovna");
$del = mysqli_query($db,"delete from ziadost where id = '$id'");

if($del)
{
    mysqli_close($db);
    header("location:booking.php?uspesne_zmazane");
    exit;
}
else
{
    echo "Error deleting record";
}
?>