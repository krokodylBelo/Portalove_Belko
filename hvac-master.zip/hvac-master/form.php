<?php

if(isset($_POST['form']))
{
    $meno = $_POST['meno'];
    $mail = $_POST['mail'];
    $priezvisko = $_POST['priezvisko'];
    $popis = $_POST['popis'];

    $db = mysqli_connect("localhost","root","","autopozicovna");

    $insert = mysqli_query($db,"INSERT INTO `ziadost` (`id`, `meno`, `mail`, `priezvisko`, `popis`) VALUES (NULL, '$meno', '$mail', '$priezvisko', '$popis');");

    if(!$insert)
    {
        echo mysqli_error($db);
    }
    else
    {
        header("location:book_request.php");
        exit;
    }
    mysqli_close($db);
}


?>


