
    <head>
        <?php include_once ("header.php"); ?>
    </head>


    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>Id</th>
                <th>Meno</th>
                <th>Cena</th>
                <th>Km</th>
                <th>typ</th>
                <th>obrazok</th>
                <th>rok</th>
                <th></th>
                <th><a href="create.php"  class="btn btn-success">Create</a></th>
            </tr>
            </thead>
            <tbody>

            <?php

            $db =mysqli_connect("localhost","root","","autopozicovna");
            $records = mysqli_query($db,"select * from auto"); // fetch data from database

            while($data = mysqli_fetch_array($records))
            {?>
                <tr>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['meno']; ?></td>
                    <td><?php echo $data['cena']; ?></td>
                    <td><?php echo $data['km']; ?></td>
                    <td><?php echo $data['typ']; ?></td>
                    <td><?php echo $data['img_path']; ?></td>
                    <td><?php echo $data['rok']; ?></td>
                    <td><a href="update.php?id=<?php echo $data['id'];?>" class="btn btn-warning">Update</a></td>

                    <td><a href="delete.php?id=<?php echo $data['id'];?>" class="btn btn-danger ">Delete</a></td>


                </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
    </div>

<?php include_once ("footer.php"); ?>



