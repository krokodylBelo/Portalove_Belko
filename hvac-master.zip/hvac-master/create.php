<?php
include ("header.php");
?>

<h3 class="text-center">Insert Data</h3>



<div class="d-flex justify-content-center mb-3">

<form action="insert.php" method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label for="meno">Nazov:</label>
        <input type="text" name="meno" class="form-control" placeholder="meno" REQUIRED>
    </div>
    <div class="form-group">
        <label for="cena">cena:</label>
        <input type="text" name="cena" class="form-control" placeholder="cena" REQUIRED>
    </div>
    <div class="form-group">
        <label for="km">km:</label>
        <input type="text" name="km" class="form-control" placeholder="km" REQUIRED>
    </div>
    <div class="form-group">
        <label for="typ">typ:</label>
        <input type="text" name="typ" class="form-control" placeholder="typ" REQUIRED>
    </div>
    <div class="form-group">
        <label for="rok">rok:</label>
        <input type="text" name="rok" class="form-control" placeholder="rok" REQUIRED>
    </div>
    <div>
        Vyber obrázok:
        <input type="file" name="fileToUpload" id="fileToUpload"  REQUIRED>
    </div>

    <button type="submit" name="submit" value="submit" class="btn btn-danger">Submit</button>
</form>
</div>

<?php include ("footer.php"); ?>